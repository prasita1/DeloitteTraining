package repo;

import model.User;

public class UserRepository extends CrudRepository<User, Integer> {

}
