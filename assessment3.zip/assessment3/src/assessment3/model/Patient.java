package assessment3.model;

import javax.persistence.*;

@Entity
@Table(name = "PATIENTS")
	

public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ins_seq")
	@SequenceGenerator(name = "ins_seq", sequenceName = "ins_seq", allocationSize = 2, initialValue = 10)
	@Column(name = "patient_id")
	private int id;

	
	@Column(name = "patient_email")
	private String email;

	@Column(name = "patient_name", nullable = false)
	private String name;
	
	@OneToMany(targetEntity = Prescription.class)
	private Prescription prescription;

	public Patient() {
		
		// TODO Auto-generated constructor stub
	}

	public Patient(int id, String email, String name, Prescription prescription) {
		
		this.id = id;
		this.email = email;
		this.name = name;
		this.prescription = prescription;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Prescription getPrescription() {
		return prescription;
	}

	public void setPrescription(Prescription prescription) {
		this.prescription = prescription;
	}
 
	}