package assessment3.model;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "PRESCRIPTION")
	

public class Prescription {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "inseq")
	@SequenceGenerator(name = "inseq", sequenceName = "inseq", allocationSize = 2, initialValue = 10)
	@Column(name = "pres_id")
	private int pid;
	
	@Column(name = "med_name", nullable = false)
	private List<Medicine> medNames;
	
	@Column(name = "patient_id")
	private int id;
	
	@OneToMany(targetEntity = Medicine.class)
	private Medicine medicine;


	public Prescription() {
		
	}


	public Prescription(int pid, List<Medicine> medNames, int id, Medicine medicine) {
		
		this.pid = pid;
		this.medNames = medNames;
		this.id = id;
		this.medicine = medicine;
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public List<Medicine> getMedNames() {
		return medNames;
	}


	public void setMedNames(List<Medicine> medNames) {
		this.medNames = medNames;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Medicine getMedicine() {
		return medicine;
	}


	public void setMedicine(Medicine medicine) {
		this.medicine = medicine;
	}

	
}
	
	
	
	