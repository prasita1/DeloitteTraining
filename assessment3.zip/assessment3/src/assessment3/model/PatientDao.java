package assessment3.model;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class PatientDao {

	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;
	
	public void create(Patient obj) {
		try(Session session = getSessionFactory().openSession()){
			session.getTransaction().begin();
			session.save(obj);
			session.getTransaction().commit();
		}
	}
	
	public void update(Patient obj) {
        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
            
            transaction = session.beginTransaction();
          
            session.update(obj);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
	
	public void delete(int id) {

        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
           
            transaction = session.beginTransaction();

           
            Patient pat = session.get(Patient.class, id);
            if (pat != null) {
                session.delete(pat);
                System.out.println("pat is deleted");
            }


          transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

	public Patient get(int id) {

        Transaction transaction = null;
        Patient pat = null;
        try (Session session = getSessionFactory().openSession()) {
            // start a transaction
            transaction = session.beginTransaction();
            // get an user object
            pat = session.get(Patient.class, id);
            // commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return pat;
    }
	
	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
		}
		return sessionFactory;
	}

	public static void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

}
