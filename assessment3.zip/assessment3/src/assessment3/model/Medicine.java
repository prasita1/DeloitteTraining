package assessment3.model;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "MEDICINES")
	

public class Medicine {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@SequenceGenerator(name = "seq", sequenceName = "seq", allocationSize = 2, initialValue = 10)
	@Column(name = "med_id")
	private int mid;
	
	@Column(name = "med_name", nullable = false)
	private List<Medicine> medNames;
	
	public Medicine() {
		
		// TODO Auto-generated constructor stub
	}
	
	public Medicine(int mid, List<Medicine> medNames) {
		
		this.mid = mid;
		this.medNames = medNames;
	}
	
	public int getMid() {
		return mid;
	}
	
	public void setMid(int mid) {
		this.mid = mid;
	}
	
	public List<Medicine> getMedNames() {
		return medNames;
	}
	
	public void setMedNames(List<Medicine> medNames) {
		this.medNames = medNames;
	}
	
	
}